package LowLevelDesign.ParkingLot.Services;

import LowLevelDesign.ParkingLot.Models.Gate;

public class GateService {
    public Gate getGate(Long gateId){
        return null;
    }
}
