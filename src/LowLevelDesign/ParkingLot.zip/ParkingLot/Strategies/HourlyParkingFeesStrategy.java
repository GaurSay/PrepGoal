package LowLevelDesign.ParkingLot.Strategies;

public class HourlyParkingFeesStrategy implements  ParkingfeesStrategy{
    @Override
    public double calculateParkingFees(long entryTime, long exitTime) {
        return 0.00;
    }
}
