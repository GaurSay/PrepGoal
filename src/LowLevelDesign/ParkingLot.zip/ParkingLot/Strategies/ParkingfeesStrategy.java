package LowLevelDesign.ParkingLot.Strategies;

public interface ParkingfeesStrategy {

    public double calculateParkingFees(long entryTime, long exitTime);
}
