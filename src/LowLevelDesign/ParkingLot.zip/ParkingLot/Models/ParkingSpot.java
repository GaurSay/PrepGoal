package LowLevelDesign.ParkingLot.Models;

import LowLevelDesign.ParkingLot.Enum.ParkingSpotStatus;
import LowLevelDesign.ParkingLot.Enum.VehicleType;

import java.util.List;

public class ParkingSpot extends BaseClass{

    private ParkingSpotStatus parkingSpotStatus;
    private List<VehicleType> supportedVehicleTypes;
    private int number;
}

